package com.eh.eden.ssm.orm.dao;


import com.eh.eden.ssm.orm.bean.Employee;

public interface EmployeeMapper {

    Employee getEmployeeById(Integer id);

}
